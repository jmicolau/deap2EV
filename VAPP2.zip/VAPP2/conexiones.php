<?php
    // Configuracion de la Base de Datos
    define('DB_HOST', 'xxx.xxx.xxx.xxx');
    define('DB_USER', 'xxxxxxxx');
    define('DB_PASS', 'xxxxxxxx');
    define('DB_DATABASE', 'xxxxxxxx');
?>